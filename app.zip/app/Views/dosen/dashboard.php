<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<style>
    body {
        background: url('/assets/image/undip vokasi.jpg') no-repeat center center fixed;
        background-size: cover;
    }

    .content-wrapper {
        background: rgba(255, 255, 255, 0.92);
        padding: 25px;
        border-radius: 10px;
        margin-top: 20px;
        box-shadow: 0 0 15px rgba(8, 7, 0, 0.15);
    }

    .student-card img {
        height:170px;
        object-fit:cover;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }

    .student-card:hover {
        transform: scale(1.03);
        transition: 0.2s;
        cursor:pointer;
    }
</style>

<!-- HEADER -->
<div style="
    background: white; padding: 15px;
    display:flex; align-items:center;
    justify-content: space-between;
    border-radius:6px;
">
    <img src="/assets/image/undip.png" style="height:70px;">
    <h3 style="
        color:black; margin:0;
        font-weight:700;
        text-transform:uppercase;
        letter-spacing:2px;
        font-family:'Poppins', sans-serif;
    ">
        Dashboard Dosen Pembimbing
    </h3>
</div>

<div class="content-wrapper">

    <!-- Logout -->
    <a href="/logout" class="btn btn-danger btn-sm mb-3">Logout</a>

    <!-- =======================
         CARD MAHASISWA BIMBINGAN
         ======================= -->
    <h5 class="mb-3" style="font-weight:700;">Daftar Mahasiswa Bimbingan</h5>

    <div class="row">

        <?php foreach($mahasiswa as $m): ?>
        <div class="col-md-3 mb-4">
            <a href="/dosen?mhs=<?= $m['id'] ?>" style="text-decoration:none; color:black;">
                <div class="card shadow-sm student-card" style="border-radius:10px;">

                    <!-- FOTO -->
                    <img src="<?= !empty($m['foto']) ? '/uploads/foto/'.$m['foto'] : '/assets/image/default-user.png' ?>" 
                         class="card-img-top">

                    <div class="card-body text-center">
                        <h5 style="font-weight:600;"><?= esc($m['nama']) ?></h5>
                        <p class="text-muted mb-1">NIM: <?= esc($m['nim']) ?></p>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; ?>

    </div>

    <hr>

    <!-- =======================
         TABEL KEGIATAN
         ======================= -->

    <h5 style="font-weight:700;">
        <?php if(isset($_GET['mhs'])): ?>
            Kegiatan Mahasiswa Terpilih
        <?php else: ?>
            Semua Kegiatan Mahasiswa
        <?php endif; ?>
    </h5>

    <table class="table table-bordered table-striped mt-3">
        <thead class="table-dark text-center">
            <tr>
                <th>Nama Mahasiswa</th>
                <th>Tanggal</th>
                <th>Lokasi Magang</th>
                <th>Detail Kegiatan Magang</th>
                <th>Status</th>
                <th>Nilai</th>
                <th>Catatan Dosen</th>
                <th>Bukti</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach($kegiatan as $row): ?>
            <tr>
                <td><?= esc($row['nama']) ?></td>
                <td><?= $row['tanggal'] ?></td>
                <td><?= esc($row['kegiatan']) ?></td>
                <td><?= esc($row['hasil']) ?></td>

                <td class="text-center">
                    <?php if ($row['nilai'] !== null): ?>
                        <span class="badge bg-success">Sudah dinilai</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Belum dinilai</span>
                    <?php endif; ?>
                </td>

                <td class="text-center"><?= $row['nilai'] ?? '-' ?></td>
                <td><?= esc($row['catatan'] ?? '-') ?></td>

                <td class="text-center">
                    <?php if (!empty($row['file'])): ?>
                        <a href="/uploads/kegiatan/<?= $row['file'] ?>" 
                           target="_blank" class="btn btn-secondary btn-sm">Lihat</a>
                    <?php else: ?>
                        <span class="text-muted">Tidak Ada</span>
                    <?php endif; ?>
                </td>

                <td class="text-center">
                    <?php if ($row['nilai'] === null): ?>
                        <a href="/penilaian/<?= $row['id'] ?>" class="btn btn-success btn-sm">Nilai</a>
                    <?php else: ?>
                        <a href="/penilaian/edit/<?= $row['id'] ?>" class="btn btn-warning btn-sm mb-1">Edit</a>
                        <br>
                        <a href="/penilaian/batal/<?= $row['id'] ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Yakin ingin membatalkan penilaian?')">
                           Batalkan
                        </a>
                    <?php endif; ?>
                </td>

            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</div>

<?= $this->endSection() ?>
