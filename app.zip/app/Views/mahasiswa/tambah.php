<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<h3>Tambah Kegiatan Magang</h3>

<a href="/mahasiswa" class="btn btn-secondary btn-sm mb-3">Kembali</a>

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
        <?= is_array(session()->getFlashdata('error')) 
            ? implode('<br>', session()->getFlashdata('error')) 
            : session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>

<form action="/kegiatan/simpan" method="post" enctype="multipart/form-data">

    <div class="mb-3">
        <label class="form-label">Tanggal</label>
        <input type="date" name="tanggal" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Lokasi / Alamat Magang</label>
        <input type="text" name="kegiatan" class="form-control" placeholder="Contoh: PT Dua Kelinci" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Detail Kegiatan Magang</label>
        <textarea name="hasil" class="form-control" rows="3" placeholder="Jelaskan kegiatan yang dilakukan..." required></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">Upload Bukti (jpg, png, pdf, doc)</label>
        <input type="file" name="file" class="form-control">
    </div>

    <button type="submit" class="btn btn-primary">Simpan</button>
</form>

<?= $this->endSection() ?>
