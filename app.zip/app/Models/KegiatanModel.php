<?php

namespace App\Models;

use CodeIgniter\Model;

class KegiatanModel extends Model
{
    protected $table = 'kegiatan';
    protected $primaryKey = 'id';

    // Tambahkan 'file'
    protected $allowedFields = [
        'id_mahasiswa',
        'tanggal',
        'kegiatan',
        'hasil',
        'file'
    ];

    public function getKegiatanWithNilai($id_mahasiswa)
    {
        return $this->select('kegiatan.*, penilaian.nilai, penilaian.catatan')
            ->join('penilaian', 'penilaian.id_kegiatan = kegiatan.id', 'left')
            ->where('kegiatan.id_mahasiswa', $id_mahasiswa)
            ->findAll();
    }
}
