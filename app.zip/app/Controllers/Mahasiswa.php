<?php

namespace App\Controllers;

use App\Models\KegiatanModel;

class Mahasiswa extends BaseController
{
 public function index()
{
    // Pastikan mahasiswa_login ada
    $mhs = session()->get('mahasiswa_login');

    if (!$mhs || $mhs['role'] !== 'mahasiswa') {
        return redirect()->to('/');
    }

    $model = new KegiatanModel();
    $data['kegiatan'] = $model->getKegiatanWithNilai($mhs['id']);

    return view('mahasiswa/dashboard', $data);
}


}
