<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function index()
    {
        return view('auth/login');
    }

    public function login()
    {
        $model = new UserModel();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $model->where('username', $username)->first();

        // Login tanpa hash (sesuai data kamu)
        if ($user && $password == $user['password']) {

            // --- SESSION DIPISAH ---

            if ($user['role'] == 'mahasiswa') {

                session()->set('mahasiswa_login', [
                    'id'   => $user['id'],
                    'nama' => $user['nama'],
                    'role' => 'mahasiswa',
                    'logged_in' => true
                ]);

                return redirect()->to('/mahasiswa');

            } else {

                session()->set('dosen_login', [
                    'id'   => $user['id'],
                    'nama' => $user['nama'],
                    'role' => 'dosen',
                    'logged_in' => true
                ]);

                return redirect()->to('/dosen');
            }
        }

        return redirect()->back()->with('error', 'Username atau password salah');
    }

    public function logout()
    {
        // Hapus session sesuai role yang sedang login
        if (session()->has('mahasiswa_login')) {
            session()->remove('mahasiswa_login');
        }

        if (session()->has('dosen_login')) {
            session()->remove('dosen_login');
        }

        return redirect()->to('/');
    }
}
