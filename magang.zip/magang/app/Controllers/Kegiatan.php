<?php

namespace App\Controllers;

use App\Models\KegiatanModel;

class Kegiatan extends BaseController
{
    // =================================================
    // FORM TAMBAH
    // =================================================
    public function tambah()
    {
        return view('mahasiswa/tambah');
    }

    // =================================================
    // SIMPAN DATA + UPLOAD FILE
    // =================================================
    public function simpan()
    {
        $model = new KegiatanModel();

        // Ambil ID mahasiswa dari session baru
        $mhs = session()->get('mahasiswa_login');
        $idMahasiswa = $mhs['id'];

        // Ambil file upload
        $file = $this->request->getFile('file');
        $namaFile = null;

        if ($file && $file->isValid() && !$file->hasMoved()) {

            // Validasi file
            $validationRule = [
                'file' => [
                    'label' => 'File Kegiatan',
                    'rules' => 'uploaded[file]|max_size[file,4096]|ext_in[file,jpg,jpeg,png,pdf,doc,docx]',
                ],
            ];

            if (!$this->validate($validationRule)) {
                return redirect()->back()->with('error', $this->validator->getErrors())->withInput();
            }

            // Nama file baru
            $namaFile = $file->getRandomName();

            // Pindahkan file ke folder uploads
            $file->move('uploads/kegiatan', $namaFile);
        }

        // Simpan ke DB
        $model->save([
            'id_mahasiswa' => $idMahasiswa,
            'tanggal'      => $this->request->getPost('tanggal'),
            'kegiatan'     => $this->request->getPost('kegiatan'),
            'hasil'        => $this->request->getPost('hasil'),
            'file'         => $namaFile,
        ]);

        return redirect()->to('/mahasiswa')->with('success', 'Kegiatan berhasil ditambahkan.');
    }

    // =================================================
    // FORM EDIT
    // =================================================
    public function edit($id)
    {
        $model = new KegiatanModel();
        $data['kegiatan'] = $model->find($id);

        return view('mahasiswa/edit', $data);
    }

    // =================================================
    // UPDATE DATA + OPSIONAL UPDATE FILE
    // =================================================
    public function update($id)
    {
        $model = new KegiatanModel();
        $kegiatan = $model->find($id);

        $file = $this->request->getFile('file');
        $namaFile = $kegiatan['file']; // pakai file lama dulu

        if ($file && $file->isValid() && !$file->hasMoved()) {

            // Validasi file baru (tidak wajib)
            $validationRule = [
                'file' => [
                    'rules' => 'max_size[file,4096]|ext_in[file,jpg,jpeg,png,pdf,doc,docx]',
                ],
            ];

            if (!$this->validate($validationRule)) {
                return redirect()->back()->with('error', $this->validator->getErrors())->withInput();
            }

            // Hapus file lama jika ada
            if ($kegiatan['file'] && file_exists('uploads/kegiatan/' . $kegiatan['file'])) {
                unlink('uploads/kegiatan/' . $kegiatan['file']);
            }

            // Upload file baru
            $namaFile = $file->getRandomName();
            $file->move('uploads/kegiatan', $namaFile);
        }

        // Update data
        $model->update($id, [
            'tanggal'  => $this->request->getPost('tanggal'),
            'kegiatan' => $this->request->getPost('kegiatan'),
            'hasil'    => $this->request->getPost('hasil'),
            'file'     => $namaFile,
        ]);

        return redirect()->to('/mahasiswa')->with('success', 'Kegiatan berhasil diperbarui.');
    }

    // =================================================
    // HAPUS DATA + CEK PENILAIAN + HAPUS FILE
    // =================================================
    public function hapus($id)
    {
        $db = \Config\Database::connect();

        // Cek apakah kegiatan sudah dinilai
        $cek = $db->table('penilaian')
                  ->where('id_kegiatan', $id)
                  ->get()
                  ->getRowArray();

        if ($cek) {
            return redirect()->back()->with('error', 'Kegiatan sudah dinilai, tidak bisa dihapus.');
        }

        $model = new KegiatanModel();
        $kegiatan = $model->find($id);

        // Hapus file
        if ($kegiatan['file'] && file_exists('uploads/kegiatan/' . $kegiatan['file'])) {
            unlink('uploads/kegiatan/' . $kegiatan['file']);
        }

        // Hapus data
        $model->delete($id);

        return redirect()->to('/mahasiswa')->with('success', 'Kegiatan berhasil dihapus.');
    }
}
