<?php

namespace App\Controllers;

use App\Models\KegiatanModel;
use App\Models\UserModel;

class Dosen extends BaseController
{
    public function index()
    {
        // Ambil session dosen
        $dosen = session()->get('dosen_login');

        // Cek apakah dosen benar-benar login
        if (!$dosen || $dosen['role'] !== 'dosen') {
            return redirect()->to('/');
        }

        $kegiatanModel = new KegiatanModel();
        $userModel     = new UserModel();

        // ============================
        // AMBIL DAFTAR MAHASISWA BIMBINGAN
        // ============================
        $data['mahasiswa'] = $userModel
            ->where('role', 'mahasiswa')
            ->orderBy('nama', 'ASC')
            ->findAll();

        // ============================
        // FILTER MAHASISWA JIKA ADA ?mhs=XX
        // ============================
        $mhsID = $this->request->getGet('mhs');

        if ($mhsID) {
            // Filter kegiatan hanya milik mahasiswa tsb
            $data['kegiatan'] = $kegiatanModel
                ->select('kegiatan.*, users.nama, penilaian.nilai, penilaian.catatan')
                ->join('users', 'users.id = kegiatan.id_mahasiswa')
                ->join('penilaian', 'penilaian.id_kegiatan = kegiatan.id', 'left')
                ->where('id_mahasiswa', $mhsID)
                ->orderBy('kegiatan.tanggal', 'DESC')
                ->findAll();

            // Ambil nama mahasiswa untuk judul filter
            $mhs = $userModel->find($mhsID);
            $data['filterNama'] = $mhs['nama'];

        } else {

            // Jika tidak memilih mahasiswa → tampilkan semua
            $data['kegiatan'] = $kegiatanModel
                ->select('kegiatan.*, users.nama, penilaian.nilai, penilaian.catatan')
                ->join('users', 'users.id = kegiatan.id_mahasiswa')
                ->join('penilaian', 'penilaian.id_kegiatan = kegiatan.id', 'left')
                ->orderBy('kegiatan.tanggal', 'DESC')
                ->findAll();

            $data['filterNama'] = null;
        }

        // Kirim ke view
        return view('dosen/dashboard', $data);
    }
}
