<?php

namespace App\Controllers;

use App\Models\PenilaianModel;
use App\Models\KegiatanModel;

class Penilaian extends BaseController
{
    public function index($id_kegiatan)
    {
        $model = new KegiatanModel();

        $data['kegiatan'] = $model
            ->select('kegiatan.*, users.nama')
            ->join('users', 'users.id = kegiatan.id_mahasiswa')
            ->where('kegiatan.id', $id_kegiatan)
            ->first();

        if (!$data['kegiatan']) {
            return redirect()->to('/dosen')->with('error', 'Kegiatan tidak ditemukan.');
        }

        return view('dosen/nilai', $data);
    }

    public function simpan($id_kegiatan)
    {
        $model = new PenilaianModel();

        $model->save([
            'id_kegiatan' => $id_kegiatan,
            'id_dosen' => session()->get('id'),
            'nilai' => $this->request->getPost('nilai'),
            'catatan' => $this->request->getPost('catatan'),
        ]);

        return redirect()->to('/dosen')->with('success', 'Nilai berhasil disimpan.');
    }

    public function edit($id_kegiatan)
    {
        $kegiatanModel = new KegiatanModel();
        $penilaianModel = new PenilaianModel();

        $data['kegiatan'] = $kegiatanModel
            ->select('kegiatan.*, users.nama')
            ->join('users', 'users.id = kegiatan.id_mahasiswa')
            ->where('kegiatan.id', $id_kegiatan)
            ->first();

        if (!$data['kegiatan']) {
            return redirect()->to('/dosen')->with('error', 'Kegiatan tidak ditemukan.');
        }

        $data['penilaian'] = $penilaianModel
            ->where('id_kegiatan', $id_kegiatan)
            ->first();

        if (!$data['penilaian']) {
            return redirect()->to('/dosen')->with('error', 'Belum ada penilaian untuk diedit.');
        }

        return view('dosen/edit_penilaian', $data);
    }

    public function update($id_kegiatan)
    {
        $model = new PenilaianModel();

        $penilaian = $model->where('id_kegiatan', $id_kegiatan)->first();

        if (!$penilaian) {
            return redirect()->to('/dosen')->with('error', 'Data penilaian tidak ditemukan.');
        }

        $model->update($penilaian['id'], [
            'nilai' => $this->request->getPost('nilai'),
            'catatan' => $this->request->getPost('catatan'),
        ]);

        return redirect()->to('/dosen')->with('success', 'Nilai berhasil diperbarui.');
    }

    public function batal($id_kegiatan)
    {
        $model = new PenilaianModel();

        $model->where('id_kegiatan', $id_kegiatan)->delete();

        return redirect()->to('/dosen')->with('success', 'Penilaian berhasil dibatalkan.');
    }
}
