<?php

namespace App\Models;
use CodeIgniter\Model;

class PenilaianModel extends Model {
    protected $table = 'penilaian';
    protected $allowedFields = ['id_kegiatan', 'id_dosen', 'nilai', 'catatan'];
}
