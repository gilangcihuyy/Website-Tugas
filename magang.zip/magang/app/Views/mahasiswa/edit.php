<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<h3>Edit Kegiatan Magang</h3>

<a href="/mahasiswa" class="btn btn-secondary btn-sm mb-3">Kembali</a>

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
        <?= is_array(session()->getFlashdata('error')) 
            ? implode('<br>', session()->getFlashdata('error')) 
            : session()->getFlashdata('error') ?>
    </div>
<?php endif; ?>

<form action="/kegiatan/update/<?= $kegiatan['id'] ?>" method="post" enctype="multipart/form-data">

    <div class="mb-3">
        <label class="form-label">Tanggal</label>
        <input type="date" name="tanggal" class="form-control"
            value="<?= $kegiatan['tanggal'] ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Lokasi / Alamat Magang</label>
        <input type="text" name="kegiatan" class="form-control"
            value="<?= esc($kegiatan['kegiatan']) ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Detail Kegiatan Magang</label>
        <textarea name="hasil" class="form-control" rows="3" required><?= esc($kegiatan['hasil']) ?></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">Bukti Upload (Opsional)</label><br>

        <?php if (!empty($kegiatan['file'])): ?>
            <p>File saat ini: 
                <a href="/uploads/kegiatan/<?= $kegiatan['file'] ?>" target="_blank">
                    <?= $kegiatan['file'] ?>
                </a>
            </p>
        <?php endif; ?>

        <input type="file" name="file" class="form-control">
        <small class="text-muted">Biarkan kosong jika tidak ingin mengganti file.</small>
    </div>

    <button type="submit" class="btn btn-warning">Perbarui</button>
</form>

<?= $this->endSection() ?>
