<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<!-- BACKGROUND HALAMAN -->
<style>
    body {
        background: url('/assets/image/undip vokasi.jpg') no-repeat center center fixed;
        background-size: cover;
    }

    /* Supaya teks tetap terbaca */
    .content-wrapper {
        background: rgba(255, 255, 255, 0.90);
        padding: 25px;
        border-radius: 10px;
        margin-top: 20px;
        box-shadow: 0 0 15px rgba(0,0,0,0.15);
    }
</style>

<!-- HEADER -->
<div style="
    background: white; 
    padding: 15px; 
    display:flex; 
    align-items:center; 
    justify-content: space-between; 
    border-radius:6px;
">

    <!-- Logo kiri -->
    <img src="/assets/image/undip.png" 
         alt="Logo UNDIP VOKASI" 
         style="height: 70px;">

    <!-- Judul kanan -->
    <h3 style="
        color: black;
        margin: 0;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 2px;
        font-family: 'Poppins', sans-serif;
    ">
        Dashboard Mahasiswa
    </h3>

</div>



<div class="content-wrapper">

    <!-- ACTION BUTTONS -->
    <div class="mt-3">
        <a href="/logout" class="btn btn-danger btn-sm">Logout</a>
        <a href="/kegiatan/tambah" class="btn btn-primary btn-sm">Tambah Kegiatan</a>
    </div>

    <!-- FLASH MESSAGES -->
    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success mt-3"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger mt-3"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>



    <!-- TABLE CONTAINER -->
    <div style="background:#f8f8f8; padding:20px; margin-top:20px; border-radius:8px;">

        <table class="table table-bordered table-striped">
            <thead class="table-primary">
                <tr>
                    <th>Tanggal</th>
                    <th>Lokasi / Alamat Magang</th>
                    <th>Detail Kegiatan Magang</th>
                    <th>Nilai</th>
                    <th>Catatan Dosen</th>
                    <th>Bukti</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach($kegiatan as $row): ?>
                <tr>
                    <td><?= $row['tanggal'] ?></td>
                    <td><?= esc($row['kegiatan']) ?></td>
                    <td><?= esc($row['hasil']) ?></td>
                    <td><?= $row['nilai'] ?? 'Belum dinilai' ?></td>
                    <td><?= $row['catatan'] ?? '-' ?></td>

                    <td>
                        <?php if (!empty($row['file'])): ?>
                            <a href="/uploads/kegiatan/<?= $row['file'] ?>" 
                               target="_blank" class="btn btn-info btn-sm">
                                Lihat
                            </a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>

                    <td>
                        <a href="/kegiatan/edit/<?= $row['id'] ?>" 
                           class="btn btn-warning btn-sm">Edit</a>

                        <a href="/kegiatan/hapus/<?= $row['id'] ?>"
                           onclick="return confirm('Hapus data ini?')"
                           class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    </div>

</div>

<?= $this->endSection() ?>
