<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<style>
    body {
        background: #e8ecf7 !important;
    }

    .login-wrapper {
        width: 850px;
        margin: 40px auto;
        background: white;
        border-radius: 20px;
        display: flex;
        overflow: hidden;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    .login-left {
        width: 50%;
        background: #4e8bff;
        color: white;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 40px;
        border-radius: 20px 100px 100px 20px;
        text-align: center;
    }

    .login-left h2 {
        font-size: 32px;
        margin-bottom: 10px;
    }

    .login-left p {
        font-size: 14px;
        opacity: .9;
    }

    .login-right {
        width: 50%;
        padding: 50px 40px;
    }

    .login-right h4 {
        text-align: center;
        margin-bottom: 25px;
        font-size: 26px;
        font-weight: 600;
    }

    .login-input {
        margin-bottom: 20px;
    }

    .login-input input {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #dcdcdc;
        background: #f3f3f3;
        border-radius: 8px;
        font-size: 15px;
    }

    .btn-login {
        width: 100%;
        padding: 12px;
        background: #4e8bff;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        color: white;
        cursor: pointer;
    }

    .btn-login:hover {
        background: #366fd6;
    }

    .alert-danger {
        font-size: 14px;
        padding: 10px;
    }

</style>

<div class="login-wrapper">

    <!-- LEFT PANEL -->
    <div class="login-left">
        <h2>Hello, Welcome!</h2>
        <p>Silakan login untuk melanjutkan</p>
    </div>

    <!-- RIGHT PANEL -->
    <div class="login-right">

        <h4>Login</h4>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form action="/login" method="post">

            <div class="login-input">
                <input type="text" name="username" placeholder="Username" required>
            </div>

            <div class="login-input">
                <input type="password" name="password" placeholder="Password" required>
            </div>

            <button class="btn-login">Login</button>
        </form>

    </div>
</div>

<?= $this->endSection() ?>
