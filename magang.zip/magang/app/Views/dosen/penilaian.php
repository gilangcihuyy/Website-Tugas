<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<h3>Penilaian Kegiatan Mahasiswa</h3>

<a href="/dosen" class="btn btn-secondary btn-sm mb-3">Kembali</a>

<div class="card">
    <div class="card-body">

        <h5>Detail Kegiatan</h5>

        <table class="table table-bordered">
            <tr>
                <th>Nama Mahasiswa</th>
                <td><?= esc($kegiatan['nama']) ?></td>
            </tr>
            <tr>
                <th>Tanggal</th>
                <td><?= esc($kegiatan['tanggal']) ?></td>
            </tr>
            <tr>
                <th>Lokasi / Alamat Magang</th>
                <td><?= esc($kegiatan['kegiatan']) ?></td>
            </tr>
            <tr>
                <th>Detail Kegiatan Magang</th>
                <td><?= esc($kegiatan['hasil']) ?></td>
            </tr>
            <tr>
                <th>Bukti</th>
                <td>
                    <?php if (!empty($kegiatan['file'])): ?>
                        <a href="/uploads/kegiatan/<?= $kegiatan['file'] ?>" 
                           target="_blank" 
                           class="btn btn-info btn-sm">
                            Lihat Bukti
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Tidak ada bukti</span>
                    <?php endif; ?>
                </td>
            </tr>
        </table>

        <hr>

        <form method="post" action="/penilaian/simpan/<?= $kegiatan['id'] ?>">

            <div class="mb-3">
                <label class="form-label">Nilai</label>
                <input type="number" name="nilai" class="form-control"
                       min="0" max="100" required
                       value="<?= $kegiatan['nilai'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Catatan Dosen</label>
                <textarea name="catatan" class="form-control" rows="3"><?= $kegiatan['catatan'] ?? '' ?></textarea>
            </div>

            <button type="submit" class="btn btn-success">Simpan</button>

        </form>

    </div>
</div>

<?= $this->endSection() ?>
