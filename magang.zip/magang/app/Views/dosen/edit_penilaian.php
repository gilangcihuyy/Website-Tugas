<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<h3>Edit Penilaian Mahasiswa</h3>

<a href="/dosen" class="btn btn-secondary btn-sm mb-3">Kembali</a>

<div class="card">
    <div class="card-body">

        <table class="table table-bordered">
            <tr>
                <th>Nama Mahasiswa</th>
                <td><?= esc($kegiatan['nama']) ?></td>
            </tr>
            <tr>
                <th>Tanggal</th>
                <td><?= esc($kegiatan['tanggal']) ?></td>
            </tr>
            <tr>
                <th>Lokasi / Alamat Magang</th>
                <td><?= esc($kegiatan['kegiatan']) ?></td>
            </tr>
            <tr>
                <th>Detail Kegiatan Magang</th>
                <td><?= esc($kegiatan['hasil']) ?></td>
            </tr>
            <tr>
                <th>Bukti</th>
                <td>
                    <?php if (!empty($kegiatan['file'])): ?>
                        <a href="/uploads/kegiatan/<?= $kegiatan['file'] ?>" 
                           target="_blank" class="btn btn-info btn-sm">
                            Lihat Bukti
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Tidak ada bukti</span>
                    <?php endif; ?>
                </td>
            </tr>
        </table>

        <form action="/penilaian/update/<?= $kegiatan['id'] ?>" method="post">

            <div class="mb-3">
                <label class="form-label">Nilai</label>
                <input type="number" name="nilai" class="form-control"
                       value="<?= $penilaian['nilai'] ?>" required min="0" max="100">
            </div>

            <div class="mb-3">
                <label class="form-label">Catatan Dosen</label>
                <textarea name="catatan" class="form-control" rows="3" required><?= $penilaian['catatan'] ?></textarea>
            </div>

            <button class="btn btn-warning">Simpan Perubahan</button>
        </form>

    </div>
</div>

<?= $this->endSection() ?>
