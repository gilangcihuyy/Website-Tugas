<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// Login
$routes->get('/', 'Auth::index');
$routes->post('/login', 'Auth::login');
$routes->get('/logout', 'Auth::logout');

// Dashboard mahasiswa
$routes->get('/mahasiswa', 'Mahasiswa::index');

// CRUD kegiatan
$routes->get('/kegiatan/tambah', 'Kegiatan::tambah');
$routes->post('/kegiatan/simpan', 'Kegiatan::simpan');

$routes->get('/kegiatan/edit/(:num)', 'Kegiatan::edit/$1');
$routes->post('/kegiatan/update/(:num)', 'Kegiatan::update/$1');

$routes->get('/kegiatan/hapus/(:num)', 'Kegiatan::hapus/$1');

// Dashboard dosen
$routes->get('/dosen', 'Dosen::index');

// Penilaian
// Penilaiannew
$routes->get('/penilaian/(:num)', 'Penilaian::index/$1');
$routes->post('/penilaian/simpan/(:num)', 'Penilaian::simpan/$1');

$routes->get('/penilaian/edit/(:num)', 'Penilaian::edit/$1');
$routes->post('/penilaian/update/(:num)', 'Penilaian::update/$1');

$routes->get('/penilaian/batal/(:num)', 'Penilaian::batal/$1');

// Edit nilai
$routes->get('/penilaian/edit/(:num)', 'Penilaian::edit/$1');
$routes->post('/penilaian/update/(:num)', 'Penilaian::update/$1');

// Batalkan nilai
$routes->get('/penilaian/batal/(:num)', 'Penilaian::batal/$1');
